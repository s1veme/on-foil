<template>

  <div class="body">
    <router-view></router-view>
  </div>

</template>

